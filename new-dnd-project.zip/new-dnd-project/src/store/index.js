/* eslint-disable no-param-reassign */
import Vue from 'vue';
import Vuex from 'vuex';

import * as R from 'ramda';

const nameLens = R.lensPath(['characterClass', 'name']);

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    bio: 'The coolest guy around.',
    name: 'philbough swaggins',
    characterClass: { name: 'bard', icon: 'music_note' },
    stats: {
      ac: { shortName: 'ac', longName: 'armor class', val: 5 },
      dex: { shortName: 'dex', longName: 'dexterity', val: 5 },
      str: { shortName: 'str', longName: 'strength', val: 5 },
      int: { shortName: 'int', longName: 'intelligence', val: 5 },
      char: { shortName: 'char', longName: 'charisma', val: 5 },
    },
  },

  actions: {
    tst({ commit }, newName) {
      commit('test', newName);
    },
  },

  mutations: {
    test(state, newName) {
      state = R.set(nameLens, newName, state);
    },
  },

  getters: {
    statsArray({ stats }) {
      return R.values(stats);
    },
  },
});
