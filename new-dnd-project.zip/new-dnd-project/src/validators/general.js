import {
  allPass, has, map, values, keys,
} from 'ramda';

// export const hasAll = allPass([has('shortName'), has('longName'), has('val')]);

// PLAN: combine has and AllPass: find/build a function that takes a function
// and a list and returns a list of functions - use that as the list of
// predicates in AllPass

// IDEA: maybe you can use one of the "while" functions (takeWhile,
// takeLastWhile, reduceWhile, dropWhile) to optimize checking more

export const hasAll = (obj, propertyNames) => {
  // keys(obj); // ?

};

export default hasAll;

/**   .-.     .-.     .-.     .-.     .-.     .-.     .-.
 `._.'   `._.'   `._.'   `._.'   `._.'   `._.'   `._.'   `._.' */

// working on hasAll

const stat = { shortName: 'ac', longName: 'armor class', val: 4 };

hasAll(stat, ['shortName', 'longName', 'val']);
