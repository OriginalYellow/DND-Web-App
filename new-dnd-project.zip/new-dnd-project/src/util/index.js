import {
  tap, uncurryN, curry, reduce, has, reduced,
} from 'ramda';

export const logTap = uncurryN(2, message => tap(x => console.log(`${message} ${x}`)));

export const hasAll = curry((keys, obj) => reduce(
  (_, item) => (has(item, obj) ? true : reduced(false)),
  false,
  keys,
));
