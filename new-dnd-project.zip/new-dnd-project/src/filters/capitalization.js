import {
  join,
  juxt,
  compose,
  toUpper,
  head,
  tail,
  map,
  split,
} from 'ramda';

// NOTE: copied from https://stackoverflow.com/questions/40011725/point-free-style-capitalize-function-with-ramda
export const Capitalize = compose(
  join(''),
  juxt([
    compose(
      toUpper,
      head,
    ),
    tail,
  ]),
);

// TEST
Capitalize('Fug shit');// ?

export const AllCaps = toUpper;

export const CapitalizeWords = compose(
  join(' '),
  map(
    Capitalize,
  ),
  split(' '),
);

// TEST
CapitalizeWords('oh my goodness');// ?
