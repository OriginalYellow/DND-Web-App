<template>
  <HomePage></HomePage>
</template>

<script>
import HomePage from './pages/HomePage.vue';

export default {
  name: 'app',

  components: {
    HomePage,
  },
};

// import { mapState, mapActions } from 'vuex';
// import CharacterSummary from './components/CharacterSummary.vue';

// export default {
//   name: 'app',

//   components: {
//     CharacterSummary,
//   },

//   computed: {
//     // ...mapState({
//     //   bio: 'bio',
//     //   name: 'name',
//     //   characterClass: 'characterClass',
//     // }),
//     ...mapState(['bio', 'name', 'characterClass']),
//   },

//   methods: {
//     // ...mapActions(['tst']),
//     tst(event) {
//       console.log('fuck vue');
//     },
//   },

//   created() {
//   },
// };
</script>
